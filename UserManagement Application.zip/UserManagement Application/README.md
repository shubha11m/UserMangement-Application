# UserManagement Web Application

A web-based user management application built with **VB.NET** and **ASP.NET Core MVC** (.NET 10). It provides user login authentication and a dashboard for viewing and editing user profile information, accessible via browser at `http://localhost:5000`.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| **Language** | VB.NET |
| **Framework** | ASP.NET Core MVC (.NET 10) |
| **Views** | Razor (`.cshtml`) with C# syntax |
| **Styling** | Custom CSS (no external frameworks) |
| **Session** | In-memory distributed cache |
| **Data** | In-memory dictionary (seeded demo data) |
| **CI/CD** | GitHub Actions → Azure App Service |

---

## Project Structure

```
UserManagement Application/
│
├── .github/
│   └── workflows/
│       └── deploy-azure.yml          # GitHub Actions CI/CD pipeline
│
├── .gitignore                         # Git ignore rules for .NET
├── UserManagement.slnx                # .NET solution file
├── README.md                          # This file
│
└── UserManagementWeb/                 # ASP.NET Core MVC project
    │
    ├── Program.vb                     # Application entry point & configuration
    ├── UserManagementWeb.vbproj       # Project file (dependencies, settings)
    ├── run.bat                        # One-click launch script (Windows)
    │
    ├── appsettings.json               # App configuration (logging, hosts)
    ├── appsettings.Development.json   # Development environment overrides
    │
    ├── Properties/
    │   └── launchSettings.json        # Launch profile (port, environment)
    │
    ├── Models/                        # Data models & business logic
    │   ├── User.vb                    # User entity (Username, Email, Phone, Address, JoinDate)
    │   ├── UserDatabase.vb            # In-memory user store with CRUD operations
    │   ├── LoginViewModel.vb          # Login form data (Username, Password, ErrorMessage)
    │   └── DashboardViewModel.vb      # Dashboard form data (user profile fields)
    │
    ├── Controllers/                   # Request handlers (MVC controllers)
    │   ├── AccountController.vb       # Login, Logout, Authentication
    │   └── DashboardController.vb     # Dashboard view, Profile update
    │
    ├── Views/                         # Razor UI templates
    │   ├── _ViewStart.cshtml          # Sets default layout for all views
    │   ├── _ViewImports.cshtml        # Shared imports & tag helpers
    │   ├── Shared/
    │   │   └── _Layout.cshtml         # HTML layout (head, body, CSS link)
    │   ├── Account/
    │   │   └── Login.cshtml           # Login page UI
    │   └── Dashboard/
    │       └── Index.cshtml           # Dashboard page UI with edit functionality
    │
    └── wwwroot/                       # Static files (served as-is)
        └── css/
            └── site.css               # All application styles
```

---

## File Descriptions

### Entry Point

| File | Description |
|------|------------|
| **`Program.vb`** | Application entry point. Configures MVC services, session management, dependency injection (registers `UserDatabase` as singleton), Razor runtime compilation, middleware pipeline (static files, routing, session), and default route (`/Account/Login`). |

### Models (`Models/`)

| File | Description |
|------|------------|
| **`User.vb`** | Entity class representing a user. Properties: `Username`, `Email`, `Phone`, `Address`, `JoinDate`. Has a parameterized constructor for seeding data. |
| **`UserDatabase.vb`** | In-memory data store using `Dictionary(Of String, User)`. Provides `Initialize()` (seeds 3 demo users), `AuthenticateUser()`, `GetUser()`, and `UpdateUser()` methods. Registered as a **singleton** via DI. |
| **`LoginViewModel.vb`** | View model for the login form. Properties: `Username`, `Password`, `ErrorMessage`. Carries form data and validation errors between controller and view. |
| **`DashboardViewModel.vb`** | View model for the dashboard. Properties: `Username`, `Email`, `Phone`, `Address`, `JoinDate`, `SuccessMessage`. Used to display and edit user profile data. |

### Controllers (`Controllers/`)

| File | Actions | Description |
|------|---------|------------|
| **`AccountController.vb`** | `Login` (GET), `Login` (POST), `Logout` | Handles authentication. GET shows login form. POST validates input (min 3 chars for username & password), authenticates against `UserDatabase`, stores username in session. Logout clears session. |
| **`DashboardController.vb`** | `Index` (GET), `Save` (POST) | Handles user dashboard. GET loads user data from `UserDatabase` into the view model. POST updates user profile (email, phone, address) and shows success message. Requires active session (redirects to login if not authenticated). |

### Views (`Views/`)

| File | Description |
|------|------------|
| **`_Layout.cshtml`** | Base HTML template. Defines `<!DOCTYPE html>`, `<head>` (meta tags, CSS link), and `<body>` with a centered container. All pages render inside `@RenderBody()`. |
| **`_ViewStart.cshtml`** | Automatically applies `_Layout.cshtml` to every view. |
| **`_ViewImports.cshtml`** | Imports `UserManagementWeb.Models` namespace and enables ASP.NET Core Tag Helpers (`asp-controller`, `asp-action`, etc.) across all views. |
| **`Account/Login.cshtml`** | Login page. Displays username/password form, error messages (red banner), and demo credentials hint box. Uses Tag Helpers for form action routing. |
| **`Dashboard/Index.cshtml`** | Dashboard page. Shows user profile in readonly fields. "Edit" button (JavaScript) enables fields with yellow highlight. "Save" submits form. "Logout" link. Displays green success banner after save. |

### Static Assets (`wwwroot/`)

| File | Description |
|------|------------|
| **`css/site.css`** | Complete application stylesheet. Includes: gradient background, card-based layout, form styling, button styles (login=purple, edit=green, save=yellow, logout=red), error/success message banners, hint box, hover animations, and responsive design. |

### Configuration Files

| File | Description |
|------|------------|
| **`UserManagementWeb.vbproj`** | Project file. Targets `net10.0`, uses `Microsoft.NET.Sdk.Web`, includes `Razor.RuntimeCompilation` package. Sets `UseAppHost=false` (required for VB.NET web apps). |
| **`appsettings.json`** | Base app configuration. Logging levels and allowed hosts. |
| **`appsettings.Development.json`** | Development-specific overrides. Enables detailed logging. |
| **`Properties/launchSettings.json`** | Launch profile. Sets URL to `http://localhost:5000` and environment to `Development`. |
| **`run.bat`** | Windows batch script. Builds the project and launches the server in one click. |

### CI/CD

| File | Description |
|------|------------|
| **`.github/workflows/deploy-azure.yml`** | GitHub Actions pipeline. **Build job:** checkout → setup .NET 10 → restore → build → publish → upload artifact. **Deploy job:** downloads artifact → deploys to Azure App Service using publish profile. Triggers on push to `main`. |

---

## Demo Users

| Username | Email | Phone | Address |
|----------|-------|-------|---------|
| `admin` | admin@example.com | +1-800-111-1111 | 100 Admin Street, New York, NY 10001 |
| `john` | john.doe@example.com | +1-800-222-2222 | 200 John Avenue, Los Angeles, CA 90001 |
| `jane` | jane.smith@example.com | +1-800-333-3333 | 300 Jane Road, Chicago, IL 60601 |

**Password:** Any text with 3 or more characters (e.g., `123`, `password`).

---

## How to Run

### Prerequisites
- [.NET 10 SDK](https://dotnet.microsoft.com/download) installed

### Option 1: Using `run.bat` (Easiest)
```
Double-click run.bat
```
Then open **http://localhost:5000** in your browser.

### Option 2: Using Terminal
```bash
cd UserManagementWeb
dotnet build
dotnet bin/Debug/net10.0/UserManagementWeb.dll
```
Set environment variables before running:
```bash
# Windows PowerShell
$env:ASPNETCORE_ENVIRONMENT = "Development"
$env:ASPNETCORE_URLS = "http://localhost:5000"

# Linux / macOS
export ASPNETCORE_ENVIRONMENT=Development
export ASPNETCORE_URLS=http://localhost:5000
```

### Option 3: Deploy to Azure
See [WORKFLOW.md](WORKFLOW.md) for full CI/CD pipeline details.

---

## Routes

| Method | URL | Controller | Action | Description |
|--------|-----|-----------|--------|-------------|
| GET | `/` | Account | Login | Login page (default route) |
| GET | `/Account/Login` | Account | Login | Login page |
| POST | `/Account/Login` | Account | Login | Authenticate user |
| GET | `/Account/Logout` | Account | Logout | Clear session, redirect to login |
| GET | `/Dashboard` | Dashboard | Index | User dashboard (requires session) |
| POST | `/Dashboard/Save` | Dashboard | Save | Update user profile |

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                    Browser (UI)                      │
│         http://localhost:5000                        │
└─────────────┬───────────────────────┬───────────────┘
              │                       │
         GET /Login              POST /Login
              │                       │
              ▼                       ▼
┌─────────────────────────────────────────────────────┐
│              ASP.NET Core MVC Pipeline               │
│  ┌─────────────┐  ┌─────────────┐  ┌────────────┐  │
│  │ Static Files│→ │  Routing    │→ │  Session   │  │
│  └─────────────┘  └─────────────┘  └────────────┘  │
└─────────────────────────┬───────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────┐
│                  Controllers                         │
│  ┌────────────────────┐  ┌───────────────────────┐  │
│  │ AccountController  │  │ DashboardController   │  │
│  │  • Login (GET/POST)│  │  • Index (GET)        │  │
│  │  • Logout          │  │  • Save (POST)        │  │
│  └────────┬───────────┘  └───────────┬───────────┘  │
└───────────┼──────────────────────────┼──────────────┘
            │                          │
            ▼                          ▼
┌─────────────────────────────────────────────────────┐
│                  Models (Data Layer)                  │
│  ┌──────────────┐  ┌─────────────────────────────┐  │
│  │ User.vb      │  │ UserDatabase.vb (Singleton) │  │
│  │ LoginVM.vb   │  │  • Initialize()             │  │
│  │ DashboardVM  │  │  • AuthenticateUser()       │  │
│  │              │  │  • GetUser() / UpdateUser()  │  │
│  └──────────────┘  └─────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────┐
│                  Views (Razor)                        │
│  ┌────────────────┐  ┌────────────────────────────┐ │
│  │ Login.cshtml   │  │ Dashboard/Index.cshtml     │ │
│  │ (form + hints) │  │ (profile + edit + JS)      │ │
│  └────────────────┘  └────────────────────────────┘ │
│            ↓ rendered using ↓                        │
│  ┌──────────────────────────────────────────────┐   │
│  │ _Layout.cshtml + site.css                    │   │
│  └──────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────┘
```

