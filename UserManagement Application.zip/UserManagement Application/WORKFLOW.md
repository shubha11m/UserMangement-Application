# CI/CD Workflow — GitHub Actions to Azure

This document describes the complete CI/CD pipeline for building and deploying the **UserManagement VB.NET Web Application** to **Azure App Service** using **GitHub Actions**.

---

## Pipeline Overview

```
┌──────────┐     ┌────────────────┐     ┌──────────────────┐     ┌────────────────┐
│  Developer│────▶│  Push to main  │────▶│  GitHub Actions   │────▶│  Azure App     │
│  commits  │     │  branch        │     │  Build & Deploy   │     │  Service       │
└──────────┘     └────────────────┘     └──────────────────┘     └────────────────┘
```

| Trigger | What Happens |
|---------|-------------|
| Push to `main` | Full pipeline: Build → Deploy to Azure |
| Pull Request to `main` | Build only (no deployment) |
| Manual (`workflow_dispatch`) | Full pipeline via GitHub UI button |

---

## Pipeline File

**Location:** `.github/workflows/deploy-azure.yml`

---

## Jobs

### Job 1: `build`

Runs on **every push and PR** to `main`.

```
Step 1 → Checkout code
Step 2 → Setup .NET 10 SDK
Step 3 → Restore NuGet packages
Step 4 → Build (Release configuration)
Step 5 → Publish (output to ./publish)
Step 6 → Upload artifact (named "webapp")
```

**Details:**

| Step | Command / Action | Purpose |
|------|-----------------|---------|
| Checkout | `actions/checkout@v4` | Clones the repository |
| Setup .NET | `actions/setup-dotnet@v4` | Installs .NET 10.x SDK on the runner |
| Restore | `dotnet restore` | Downloads NuGet dependencies |
| Build | `dotnet build --configuration Release` | Compiles VB.NET code in Release mode |
| Publish | `dotnet publish --configuration Release --output ./publish` | Creates deployment-ready output |
| Upload | `actions/upload-artifact@v4` | Saves build output for the deploy job |

### Job 2: `deploy`

Runs **only on push to `main`** (not on PRs). Depends on `build` job succeeding.

```
Step 1 → Download build artifact
Step 2 → Deploy to Azure Web App
```

**Details:**

| Step | Command / Action | Purpose |
|------|-----------------|---------|
| Download | `actions/download-artifact@v4` | Retrieves the published app from build job |
| Deploy | `azure/webapps-deploy@v3` | Pushes the app to Azure App Service |

---

## Pipeline Flow Diagram

```
                    ┌─────────────────────┐
                    │   git push (main)   │
                    └──────────┬──────────┘
                               │
                               ▼
                ┌──────────────────────────────┐
                │          BUILD JOB            │
                │                              │
                │  ┌────────────────────────┐  │
                │  │ 1. Checkout code       │  │
                │  └───────────┬────────────┘  │
                │              ▼               │
                │  ┌────────────────────────┐  │
                │  │ 2. Setup .NET 10 SDK   │  │
                │  └───────────┬────────────┘  │
                │              ▼               │
                │  ┌────────────────────────┐  │
                │  │ 3. dotnet restore      │  │
                │  └───────────┬────────────┘  │
                │              ▼               │
                │  ┌────────────────────────┐  │
                │  │ 4. dotnet build        │  │
                │  │    (Release mode)      │  │
                │  └───────────┬────────────┘  │
                │              ▼               │
                │  ┌────────────────────────┐  │
                │  │ 5. dotnet publish      │  │
                │  │    → ./publish/        │  │
                │  └───────────┬────────────┘  │
                │              ▼               │
                │  ┌────────────────────────┐  │
                │  │ 6. Upload artifact     │  │
                │  │    (name: "webapp")    │  │
                │  └────────────────────────┘  │
                └──────────────┬───────────────┘
                               │
                    (only if branch == main)
                               │
                               ▼
                ┌──────────────────────────────┐
                │         DEPLOY JOB            │
                │                              │
                │  ┌────────────────────────┐  │
                │  │ 1. Download artifact   │  │
                │  │    (name: "webapp")    │  │
                │  └───────────┬────────────┘  │
                │              ▼               │
                │  ┌────────────────────────┐  │
                │  │ 2. Deploy to Azure     │  │
                │  │    App Service         │  │
                │  │    (publish profile)   │  │
                │  └────────────────────────┘  │
                └──────────────┬───────────────┘
                               │
                               ▼
                ┌──────────────────────────────┐
                │   ✅ Live on Azure            │
                │   https://<app-name>         │
                │          .azurewebsites.net  │
                └──────────────────────────────┘
```

---

## Azure Setup (One-Time)

### Step 1: Create Azure App Service

1. Go to [Azure Portal](https://portal.azure.com)
2. Click **Create a resource** → **Web App**
3. Configure:

| Setting | Value |
|---------|-------|
| **Name** | `usermanagement-webapp` (or your choice) |
| **Runtime stack** | .NET 10 |
| **Operating System** | Linux |
| **Region** | Choose nearest region |
| **Pricing Plan** | Free (F1) for testing, or Basic (B1)+ for production |

4. Click **Review + Create** → **Create**

### Step 2: Download Publish Profile

1. Go to your App Service in Azure Portal
2. Click **Overview** → **Download publish profile**
3. Save the `.PublishSettings` file (it contains XML)

### Step 3: Add GitHub Secret

1. Go to your GitHub repository
2. Navigate to **Settings** → **Secrets and variables** → **Actions**
3. Click **New repository secret**
4. Fill in:

| Field | Value |
|-------|-------|
| **Name** | `AZURE_WEBAPP_PUBLISH_PROFILE` |
| **Secret** | Paste the **entire XML content** of the `.PublishSettings` file |

5. Click **Add secret**

### Step 4: Update App Name in Workflow

Open `.github/workflows/deploy-azure.yml` and update:

```yaml
env:
  AZURE_WEBAPP_NAME: usermanagement-webapp   # ← Your actual Azure App Service name
```

---

## Environment Variables

The pipeline uses these variables:

| Variable | Value | Where Set |
|----------|-------|-----------|
| `AZURE_WEBAPP_NAME` | Your App Service name | In `deploy-azure.yml` |
| `DOTNET_VERSION` | `10.0.x` | In `deploy-azure.yml` |
| `PROJECT_PATH` | `UserManagementWeb/UserManagementWeb.vbproj` | In `deploy-azure.yml` |
| `AZURE_WEBAPP_PUBLISH_PROFILE` | Publish profile XML | GitHub Secrets |

---

## How to Trigger the Pipeline

### Automatic (on every push)
```bash
git add .
git commit -m "your changes"
git push origin main
```

### Manual (from GitHub UI)
1. Go to your GitHub repo → **Actions** tab
2. Select **Build and Deploy to Azure** workflow
3. Click **Run workflow** → **Run workflow**

---

## Monitoring

### GitHub Actions
- Go to your repo → **Actions** tab
- Click on the latest run to see logs for each step
- ✅ Green = success | ❌ Red = failure

### Azure Portal
- Go to your App Service → **Log stream** for live logs
- App Service → **Deployment Center** for deployment history

---

## Troubleshooting

| Issue | Solution |
|-------|---------|
| Build fails with "SDK not found" | Verify `DOTNET_VERSION: '10.0.x'` in the workflow matches available SDK |
| Deploy fails with "publish profile" error | Re-download the publish profile from Azure and update the GitHub secret |
| App shows 500 error on Azure | Check **Log stream** in Azure Portal; ensure `ASPNETCORE_ENVIRONMENT` is set to `Production` in App Service → Configuration → Application settings |
| Views not found on Azure | The `Razor.RuntimeCompilation` package handles this — ensure it's in the project dependencies |

---

## Local Development vs Production

| Aspect | Local (`run.bat`) | Azure (Pipeline) |
|--------|-------------------|-------------------|
| URL | `http://localhost:5000` | `https://<app-name>.azurewebsites.net` |
| Environment | Development | Production |
| Error pages | Detailed developer exception page | Generic error page |
| Build config | Debug | Release |
| Launch command | `dotnet UserManagementWeb.dll` | Managed by Azure App Service |

