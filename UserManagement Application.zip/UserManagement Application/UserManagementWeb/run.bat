@echo off
echo ==========================================
echo   UserManagement Web Application (VB.NET)
echo ==========================================
echo.

cd /d "%~dp0"

set ASPNETCORE_ENVIRONMENT=Development
set ASPNETCORE_URLS=http://localhost:5000

echo Building...
dotnet build UserManagementWeb.vbproj
if %errorlevel% neq 0 (
    echo Build failed!
    pause
    exit /b 1
)

echo.
echo ==========================================
echo   Open your browser to:
echo   http://localhost:5000
echo ==========================================
echo.
echo   Demo Users: admin, john, jane
echo   Password: any 3+ characters
echo.
echo   Press Ctrl+C to stop the server.
echo ==========================================
echo.

dotnet "bin\Debug\net10.0\UserManagementWeb.dll"
pause

