Imports Microsoft.AspNetCore.Mvc
Imports Microsoft.AspNetCore.Http
Imports UserManagementWeb.Models

Namespace UserManagementWeb.Controllers
    Public Class DashboardController
        Inherits Controller

        Private ReadOnly _db As UserDatabase

        Public Sub New(db As UserDatabase)
            _db = db
        End Sub

        ' GET: /Dashboard
        <HttpGet>
        Public Function Index() As IActionResult
            Dim username = HttpContext.Session.GetString("Username")
            If String.IsNullOrEmpty(username) Then
                Return RedirectToAction("Login", "Account")
            End If

            Dim user = _db.GetUser(username)
            If user Is Nothing Then
                Return RedirectToAction("Login", "Account")
            End If

            Dim model As New DashboardViewModel() With {
                .Username = user.Username,
                .Email = user.Email,
                .Phone = user.Phone,
                .Address = user.Address,
                .JoinDate = user.JoinDate.ToString("MM/dd/yyyy")
            }
            Return View(model)
        End Function

        ' POST: /Dashboard/Save
        <HttpPost>
        Public Function Save(model As DashboardViewModel) As IActionResult
            Dim username = HttpContext.Session.GetString("Username")
            If String.IsNullOrEmpty(username) Then
                Return RedirectToAction("Login", "Account")
            End If

            Dim user = _db.GetUser(username)
            If user IsNot Nothing Then
                user.Email = If(model.Email, user.Email)
                user.Phone = If(model.Phone, user.Phone)
                user.Address = If(model.Address, user.Address)
                _db.UpdateUser(user)
            End If

            model.Username = username
            model.JoinDate = If(user IsNot Nothing, user.JoinDate.ToString("MM/dd/yyyy"), "")
            model.SuccessMessage = "User information updated successfully!"
            Return View("Index", model)
        End Function
    End Class
End Namespace

