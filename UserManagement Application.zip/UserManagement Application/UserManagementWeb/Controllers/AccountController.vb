Imports Microsoft.AspNetCore.Mvc
Imports Microsoft.AspNetCore.Http
Imports UserManagementWeb.Models

Namespace UserManagementWeb.Controllers
    Public Class AccountController
        Inherits Controller

        Private ReadOnly _db As UserDatabase

        Public Sub New(db As UserDatabase)
            _db = db
        End Sub

        ' GET: /Account/Login
        <HttpGet>
        Public Function Login() As IActionResult
            ' If already logged in, redirect to dashboard
            If Not String.IsNullOrEmpty(HttpContext.Session.GetString("Username")) Then
                Return RedirectToAction("Index", "Dashboard")
            End If
            Return View(New LoginViewModel())
        End Function

        ' POST: /Account/Login
        <HttpPost>
        Public Function Login(model As LoginViewModel) As IActionResult
            ' Validate inputs
            If String.IsNullOrWhiteSpace(model.Username) Then
                model.ErrorMessage = "Please enter a username"
                Return View(model)
            End If

            If String.IsNullOrWhiteSpace(model.Password) Then
                model.ErrorMessage = "Please enter a password"
                Return View(model)
            End If

            If model.Username.Length < 3 Then
                model.ErrorMessage = "Username must be at least 3 characters"
                Return View(model)
            End If

            If model.Password.Length < 3 Then
                model.ErrorMessage = "Password must be at least 3 characters"
                Return View(model)
            End If

            ' Authenticate
            If _db.AuthenticateUser(model.Username, model.Password) Then
                HttpContext.Session.SetString("Username", model.Username.ToLower())
                Return RedirectToAction("Index", "Dashboard")
            End If

            model.ErrorMessage = "Invalid username or password"
            Return View(model)
        End Function

        ' GET: /Account/Logout
        Public Function Logout() As IActionResult
            HttpContext.Session.Clear()
            Return RedirectToAction("Login")
        End Function
    End Class
End Namespace

