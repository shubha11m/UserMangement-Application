Namespace UserManagementWeb.Models
    Public Class DashboardViewModel
        Public Property Username As String
        Public Property Email As String
        Public Property Phone As String
        Public Property Address As String
        Public Property JoinDate As String
        Public Property SuccessMessage As String
    End Class
End Namespace

