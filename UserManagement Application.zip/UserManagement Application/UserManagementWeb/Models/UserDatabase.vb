Namespace UserManagementWeb.Models
    Public Class UserDatabase
        Private users As New Dictionary(Of String, User)()

        Public Sub Initialize()
            users.Add("admin", New User("admin", "admin@example.com", "+1-800-111-1111", "100 Admin Street, New York, NY 10001", DateTime.Now.AddYears(-2)))
            users.Add("john", New User("john", "john.doe@example.com", "+1-800-222-2222", "200 John Avenue, Los Angeles, CA 90001", DateTime.Now.AddMonths(-12)))
            users.Add("jane", New User("jane", "jane.smith@example.com", "+1-800-333-3333", "300 Jane Road, Chicago, IL 60601", DateTime.Now.AddMonths(-6)))
        End Sub

        Public Function AuthenticateUser(username As String, password As String) As Boolean
            Return users.ContainsKey(username.ToLower()) AndAlso password.Length >= 3
        End Function

        Public Function GetUser(username As String) As User
            If users.ContainsKey(username.ToLower()) Then
                Return users(username.ToLower())
            End If
            Return Nothing
        End Function

        Public Sub UpdateUser(user As User)
            If users.ContainsKey(user.Username.ToLower()) Then
                users(user.Username.ToLower()) = user
            End If
        End Sub
    End Class
End Namespace

