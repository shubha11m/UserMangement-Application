Namespace UserManagementWeb.Models
    Public Class LoginViewModel
        Public Property Username As String
        Public Property Password As String
        Public Property ErrorMessage As String
    End Class
End Namespace

