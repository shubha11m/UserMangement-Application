Imports Microsoft.AspNetCore.Builder
Imports Microsoft.Extensions.DependencyInjection
Imports Microsoft.Extensions.Hosting
Imports UserManagementWeb.Models

Public Class Program
    Public Shared Sub Main(args As String())
        Dim builder = WebApplication.CreateBuilder(New WebApplicationOptions() With {
            .Args = args,
            .ContentRootPath = System.IO.Directory.GetCurrentDirectory()
        })

        builder.Services.AddControllersWithViews().AddRazorRuntimeCompilation()
        builder.Services.AddDistributedMemoryCache()
        builder.Services.AddSession(Sub(opt)
                                        opt.IdleTimeout = TimeSpan.FromMinutes(30)
                                        opt.Cookie.HttpOnly = True
                                        opt.Cookie.IsEssential = True
                                    End Sub)
        builder.Services.AddSingleton(Of UserDatabase)()

        Dim app = builder.Build()

        Dim db = app.Services.GetRequiredService(Of UserDatabase)()
        db.Initialize()

        If app.Environment.IsDevelopment() Then
            app.UseDeveloperExceptionPage()
        Else
            app.UseExceptionHandler("/Home/Error")
        End If

        app.UseStaticFiles()
        app.UseRouting()
        app.UseSession()

        app.MapControllerRoute(
            name:="default",
            pattern:="{controller=Account}/{action=Login}/{id?}")

        app.Run()
    End Sub
End Class
